package com.numberlist;

public class Main {

	public static void main(String[] args) {

		GuestBoard guestBoard = new GuestBoard();
		guestBoard.run();
	}

}
